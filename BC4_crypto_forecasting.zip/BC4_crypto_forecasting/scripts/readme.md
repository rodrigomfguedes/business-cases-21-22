# Work Logs

 
## Work Log 1 (27/04/2022)

- Loaded the excel files
- Merged them into a single DF
- Split the information for every cryptocurrency into it's own dataframe (10 in total, df_ADA, df_ATOM...) 
- Each DF contains the specific market_metrics for each crypto ('ADJCLOSE', 'CLOSE', 'HIGH', 'LOW', 'OPEN', 'VOLUME')

## Work Log 2 (28/04/2022)
- Decision of extract the DF for each currency and then, build different models for each one. With this decision, we will work on 10 notebooks.
- We deleted the rows with Nan values. After that we check duplicates, we changed date to datime.
- We create new features, pctdif_closeopen and pctdif_highlow to see the differences between close and open values and high and low values.
- 

## Contributors:

- Rodrigo Guedes
- Diogo Pires 
- Catarina Garcez
- Beatriz Selidónio

